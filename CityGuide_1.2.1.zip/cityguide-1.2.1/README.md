City Guide
==========

This is a City Guide app created by [Robo Templates](http://robotemplates.com/).
See documentation in _/doc_ directory for more info.
