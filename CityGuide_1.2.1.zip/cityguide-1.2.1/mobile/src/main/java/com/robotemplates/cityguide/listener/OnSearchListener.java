package com.robotemplates.cityguide.listener;


public interface OnSearchListener
{
	void onSearch(String query);
}
